
import React, { useState } from 'react';
import { Trip, TripStatus, User } from '../types.ts';
import { getMapLink } from '../utils/geoUtils.ts';
import { CheckCircle, XCircle, ExternalLink, Download, Search, Edit3, TrendingUp, User as UserIcon, Calendar, FileText, Map as MapIcon, Image as ImageIcon, Smartphone } from 'lucide-react';

interface ManagerDashboardProps {
  user: User;
  trips: Trip[];
  onTripsUpdate: (trips: Trip[]) => void;
}

const ManagerDashboard: React.FC<ManagerDashboardProps> = ({ user, trips, onTripsUpdate }) => {
  const [editingTrip, setEditingTrip] = useState<Trip | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState<TripStatus | 'ALL'>('PENDING_APPROVAL');

  const myManagedTrips = trips.filter(t => t.managerId === user.id);

  const filtered = myManagedTrips.filter(t => {
    const matchesFilter = filter === 'ALL' || t.status === filter;
    const matchesSearch = t.employeeName.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          (t.destinationName?.toLowerCase() || '').includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const handleUpdateTrip = (id: string, updates: Partial<Trip>) => {
    onTripsUpdate(trips.map(t => t.id === id ? { ...t, ...updates } : t));
    setEditingTrip(null);
  };

  const exportManagedReport = () => {
    const headers = ['Employee Name', 'Emp ID', 'Date', 'Start Reading', 'End Reading', 'Gross KM', 'Deduction KM', 'Net KM', 'Start Map', 'End Map', 'Status'];
    const rows = myManagedTrips.map(t => [
      t.employeeName,
      t.employeeId,
      new Date(t.startTime).toLocaleDateString(),
      t.startOdometerReading,
      t.endOdometerReading || '-',
      t.distanceKm || 0,
      t.deductionKm || 0,
      t.finalApprovedDistance || 0,
      getMapLink(t.startLocation.latitude, t.startLocation.longitude),
      t.endLocation ? getMapLink(t.endLocation.latitude, t.endLocation.longitude) : 'N/A',
      t.status
    ]);
    const csvContent = "data:text/csv;charset=utf-8," + headers.join(",") + "\n" + rows.map(e => e.join(",")).join("\n");
    const link = document.createElement("a");
    link.href = encodeURI(csvContent);
    link.download = `detailed_conveyance_report_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-8 rounded-[2rem] shadow-sm border border-slate-100">
           <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Total Approved Dist</span>
           <p className="text-4xl font-black text-slate-900 tracking-tighter mt-2">
            {myManagedTrips.reduce((acc, c) => acc + (c.finalApprovedDistance || 0), 0).toFixed(1)} <span className="text-sm font-bold text-slate-400 uppercase">km</span>
          </p>
        </div>
        <div className="bg-white p-8 rounded-[2rem] shadow-sm border border-slate-100">
           <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Awaiting Review</span>
           <p className="text-4xl font-black text-amber-500 tracking-tighter mt-2">
            {myManagedTrips.filter(t => t.status === 'PENDING_APPROVAL').length} <span className="text-sm font-bold text-amber-200 uppercase">Trips</span>
          </p>
        </div>
        <button onClick={exportManagedReport} className="bg-indigo-600 text-white p-8 rounded-[2rem] shadow-2xl shadow-indigo-200 flex items-center justify-center gap-4 hover:bg-indigo-700 transition-all group">
          <FileText className="w-10 h-10 group-hover:scale-110 transition-transform" />
          <div className="text-left">
            <p className="font-black text-xl leading-none tracking-tight">Generate Excel</p>
            <p className="text-[10px] font-bold text-indigo-200 uppercase tracking-widest mt-1">Full History Report</p>
          </div>
        </button>
      </div>

      <div className="bg-white rounded-[2.5rem] shadow-xl border border-slate-100 overflow-hidden">
        <div className="p-8 border-b flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="relative w-full sm:w-80">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
            <input type="text" placeholder="Search by name or destination..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="pl-12 pr-6 py-4 bg-slate-50 rounded-2xl border-none text-sm font-medium w-full focus:ring-2 focus:ring-indigo-500 transition-all" />
          </div>
          <div className="flex gap-2 bg-slate-100 p-1.5 rounded-2xl w-full sm:w-auto">
            {(['PENDING_APPROVAL', 'ALL'] as const).map(f => (
              <button key={f} onClick={() => setFilter(f)} className={`flex-1 sm:flex-none px-8 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${filter === f ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>{f === 'PENDING_APPROVAL' ? 'Queue' : 'All'}</button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50/50 text-[10px] font-black text-slate-400 uppercase tracking-widest border-b">
              <tr>
                <th className="px-8 py-6">Staff Member</th>
                <th className="px-8 py-6">Location Proofs</th>
                <th className="px-8 py-6">Meter & Distance</th>
                <th className="px-8 py-6">Status</th>
                <th className="px-8 py-6 text-right">Review</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map(trip => (
                <tr key={trip.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-8 py-6">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-2xl bg-indigo-50 flex items-center justify-center text-indigo-500"><UserIcon className="w-6 h-6" /></div>
                      <div>
                        <p className="font-black text-slate-900 text-base leading-none">{trip.employeeName}</p>
                        <p className="text-[10px] font-bold text-slate-400 mt-2 uppercase tracking-widest">ID: {trip.employeeId}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <div className="flex flex-col gap-2">
                      <a href={getMapLink(trip.startLocation.latitude, trip.startLocation.longitude)} target="_blank" className="flex items-center gap-2 text-[10px] font-black text-indigo-600 hover:bg-indigo-100 uppercase bg-indigo-50 px-3 py-1.5 rounded-xl w-fit transition-all">
                        <MapIcon className="w-3.5 h-3.5" /> Start Point
                      </a>
                      {trip.endLocation && (
                        <a href={getMapLink(trip.endLocation.latitude, trip.endLocation.longitude)} target="_blank" className="flex items-center gap-2 text-[10px] font-black text-rose-600 hover:bg-rose-100 uppercase bg-rose-50 px-3 py-1.5 rounded-xl w-fit transition-all">
                          <MapIcon className="w-3.5 h-3.5" /> End Point
                        </a>
                      )}
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <div className="space-y-2">
                      <div className="flex justify-between w-32 text-xs font-bold text-slate-500">
                        <span>Readings:</span>
                        <span className="text-slate-900">{trip.startOdometerReading} → {trip.endOdometerReading || '?'}</span>
                      </div>
                      <div className="flex justify-between w-32 text-xs font-bold text-indigo-600">
                        <span>Approved:</span>
                        <span className="font-black">{trip.finalApprovedDistance || trip.distanceKm} km</span>
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-6">
                    <span className={`text-[10px] font-black px-3 py-1.5 rounded-xl uppercase tracking-widest ${
                      trip.status === 'APPROVED' ? 'bg-emerald-100 text-emerald-700' : 
                      trip.status === 'REJECTED' ? 'bg-rose-100 text-rose-700' : 'bg-amber-100 text-amber-700'
                    }`}>{trip.status.replace('_', ' ')}</span>
                  </td>
                  <td className="px-8 py-6 text-right">
                    {trip.status === 'PENDING_APPROVAL' ? (
                      <button onClick={() => setEditingTrip(trip)} className="p-3 bg-slate-900 text-white rounded-2xl hover:bg-slate-800 transition-all shadow-lg active:scale-95">
                        <Edit3 className="w-5 h-5" />
                      </button>
                    ) : (
                      <div className="w-10 h-10 inline-flex items-center justify-center bg-slate-50 rounded-full text-slate-300"><CheckCircle className="w-6 h-6" /></div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {editingTrip && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-[100] flex items-center justify-center p-4">
          <div className="bg-white rounded-[3rem] w-full max-w-xl overflow-hidden shadow-2xl animate-in zoom-in-95 duration-300">
            <div className="p-12 border-b bg-slate-50/50">
              <h3 className="text-3xl font-black text-slate-900 tracking-tight">Review Request</h3>
              <div className="flex items-center gap-3 mt-2">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">{editingTrip.employeeName}</span>
                <span className="w-1 h-1 bg-slate-300 rounded-full"></span>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">ID: {editingTrip.employeeId}</span>
              </div>
            </div>
            
            <div className="p-12 space-y-10">
              <div className="grid grid-cols-2 gap-8">
                <div className="space-y-4">
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Evidence Photos</p>
                  <div className="flex gap-3">
                    <a href={editingTrip.startOdometerImageUrl} target="_blank" className="flex-1 aspect-square bg-slate-100 rounded-3xl flex items-center justify-center text-slate-400 hover:bg-indigo-50 hover:text-indigo-600 transition-all border border-slate-200">
                      <ImageIcon className="w-8 h-8" />
                    </a>
                    <a href={editingTrip.endOdometerImageUrl} target="_blank" className="flex-1 aspect-square bg-slate-100 rounded-3xl flex items-center justify-center text-slate-400 hover:bg-rose-50 hover:text-rose-600 transition-all border border-slate-200">
                      <ImageIcon className="w-8 h-8" />
                    </a>
                  </div>
                </div>
                <div className="space-y-4">
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Stats</p>
                  <div className="p-6 bg-indigo-600 rounded-[2rem] text-white shadow-xl shadow-indigo-200">
                    <p className="text-[9px] font-bold uppercase tracking-widest opacity-80 mb-1">Gross Distance</p>
                    <p className="text-3xl font-black">{editingTrip.distanceKm} <span className="text-xs">km</span></p>
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">KM Deduction (Personal Use, etc)</label>
                  <div className="relative">
                    <Smartphone className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                    <input type="number" step="0.1" className="w-full pl-12 pr-6 py-5 bg-slate-50 border border-slate-100 rounded-3xl focus:ring-2 focus:ring-indigo-500 outline-none font-black text-xl" placeholder="0.0" onChange={(e) => {
                        const ded = parseFloat(e.target.value) || 0;
                        setEditingTrip({...editingTrip, deductionKm: ded, finalApprovedDistance: Math.max(0, (editingTrip.distanceKm || 0) - ded)});
                      }} />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Official Notes</label>
                  <textarea className="w-full p-6 bg-slate-50 border border-slate-100 rounded-[2rem] focus:ring-2 focus:ring-indigo-500 outline-none font-medium text-sm h-32 resize-none" placeholder="Explain deductions or reason for rejection..." onChange={(e) => setEditingTrip({...editingTrip, managerNotes: e.target.value})}></textarea>
                </div>
              </div>
            </div>

            <div className="p-12 bg-slate-50 border-t flex flex-wrap gap-4">
              <button onClick={() => setEditingTrip(null)} className="flex-1 py-5 bg-white text-slate-600 rounded-3xl font-black uppercase tracking-widest text-[10px] hover:bg-slate-100 transition-all border border-slate-200">Cancel</button>
              <button onClick={() => handleUpdateTrip(editingTrip.id, {status: 'REJECTED', managerNotes: editingTrip.managerNotes})} className="flex-1 py-5 bg-rose-50 text-rose-600 rounded-3xl font-black uppercase tracking-widest text-[10px] hover:bg-rose-100 transition-all">Reject</button>
              <button onClick={() => handleUpdateTrip(editingTrip.id, {
                  status: 'APPROVED', 
                  deductionKm: editingTrip.deductionKm,
                  finalApprovedDistance: editingTrip.finalApprovedDistance,
                  managerNotes: editingTrip.managerNotes
                })} className="flex-[2] py-5 bg-indigo-600 text-white rounded-3xl font-black uppercase tracking-widest text-[10px] hover:bg-indigo-700 transition-all shadow-2xl">Approve Trip</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ManagerDashboard;
