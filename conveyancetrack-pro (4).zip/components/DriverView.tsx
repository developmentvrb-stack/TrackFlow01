
import React, { useState, useRef, useEffect } from 'react';
import { Trip, User } from '../types.ts';
import { getCurrentPosition } from '../utils/geoUtils.ts';
import { extractOdometerReading } from '../services/geminiService.ts';
import { Camera, MapPin, Clock, Navigation, AlertCircle, Loader2, Play, Square, CheckCircle2, ChevronRight, Download } from 'lucide-react';

interface DriverViewProps {
  user: User;
  trips: Trip[];
  onTripsUpdate: (trips: Trip[]) => void;
}

const DriverView: React.FC<DriverViewProps> = ({ user, trips, onTripsUpdate }) => {
  const [activeTrip, setActiveTrip] = useState<Trip | null>(null);
  const [loading, setLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');
  const [error, setError] = useState('');
  const [destination, setDestination] = useState('');
  
  const startFileRef = useRef<HTMLInputElement>(null);
  const endFileRef = useRef<HTMLInputElement>(null);

  const myTrips = trips.filter(t => t.employeeId === user.id);

  useEffect(() => {
    const current = myTrips.find(t => t.status === 'IN_PROGRESS');
    setActiveTrip(current || null);
  }, [trips, user.id]);

  const handleStartTrip = async () => {
    setLoading(true);
    setError('');
    try {
      await getCurrentPosition();
      startFileRef.current?.click();
    } catch (err: any) {
      setError('GPS required to start trip.');
      setLoading(false);
    }
  };

  const handleEndTripStart = () => {
    if (!destination) { setError('Enter destination first.'); return; }
    setError('');
    endFileRef.current?.click();
  };

  const onStartPhoto = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) { setLoading(false); return; }

    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = reader.result as string;
      setStatusMessage('AI Reading Start Meter...');
      try {
        const reading = await extractOdometerReading(base64);
        if (reading === null) { setError('Could not read meter.'); return; }
        const location = await getCurrentPosition();
        const newTrip: Trip = {
          id: `TRIP-${Date.now()}`,
          employeeId: user.id,
          employeeName: user.name,
          managerId: user.assignedManagerId || 'MGR-DEFAULT',
          startTime: new Date().toISOString(),
          startLocation: location,
          startOdometerReading: reading,
          startOdometerImageUrl: base64,
          status: 'IN_PROGRESS',
          createdAt: new Date().toISOString(),
        };
        onTripsUpdate([...trips, newTrip]);
      } catch (err) { setError('Initialization failed.'); }
      finally { setLoading(false); setStatusMessage(''); }
    };
    reader.readAsDataURL(file);
  };

  const onEndPhoto = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !activeTrip) return;

    setLoading(true);
    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = reader.result as string;
      setStatusMessage('AI Reading End Meter...');
      try {
        const reading = await extractOdometerReading(base64);
        if (reading === null || reading <= activeTrip.startOdometerReading) {
          setError(`Invalid reading (Must be > ${activeTrip.startOdometerReading}).`);
          return;
        }
        const location = await getCurrentPosition();
        const distance = reading - activeTrip.startOdometerReading;
        
        const updatedTrip: Trip = {
          ...activeTrip,
          endTime: new Date().toISOString(),
          endLocation: location,
          endOdometerReading: reading,
          endOdometerImageUrl: base64,
          destinationName: destination,
          status: 'PENDING_APPROVAL',
          distanceKm: distance,
          finalApprovedDistance: distance,
        };

        onTripsUpdate(trips.map(t => t.id === activeTrip.id ? updatedTrip : t));
        setDestination('');
      } catch (err) { setError('Finalization failed.'); }
      finally { setLoading(false); setStatusMessage(''); }
    };
    reader.readAsDataURL(file);
  };

  const downloadPersonalReport = () => {
    const headers = ['Date', 'Start Reading', 'End Reading', 'Gross Dist', 'Deductions', 'Approved Dist', 'Destination', 'Status'];
    const rows = myTrips.map(t => [
      new Date(t.startTime).toLocaleDateString(),
      t.startOdometerReading,
      t.endOdometerReading || '-',
      t.distanceKm || 0,
      t.deductionKm || 0,
      t.finalApprovedDistance || 0,
      t.destinationName || 'N/A',
      t.status
    ]);
    const csvContent = "data:text/csv;charset=utf-8," + headers.join(",") + "\n" + rows.map(e => e.join(",")).join("\n");
    const link = document.createElement("a");
    link.href = encodeURI(csvContent);
    link.download = `report_${user.id}_${new Date().getMonth()+1}.csv`;
    link.click();
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="bg-white rounded-3xl shadow-xl border border-slate-100 p-8">
        <div className="flex justify-between items-start mb-8">
          <h2 className="text-2xl font-black text-slate-800 tracking-tight flex items-center gap-2">
            <Navigation className="text-indigo-600" />
            {activeTrip ? 'Current Trip' : 'Start Journey'}
          </h2>
          {!activeTrip && myTrips.length > 0 && (
            <button onClick={downloadPersonalReport} className="flex items-center gap-2 text-xs font-bold text-indigo-600 uppercase bg-indigo-50 px-3 py-2 rounded-lg hover:bg-indigo-100 transition-all">
              <Download className="w-3.5 h-3.5" /> My Report
            </button>
          )}
        </div>

        {activeTrip ? (
          <div className="space-y-6">
            <div className="bg-indigo-50 border border-indigo-100 p-6 rounded-2xl">
              <div className="flex justify-between items-center mb-4">
                <span className="text-[10px] font-black text-indigo-600 uppercase tracking-widest bg-white px-2 py-1 rounded-md shadow-sm">Running</span>
                <span className="text-xs font-bold text-slate-400">{new Date(activeTrip.startTime).toLocaleTimeString()}</span>
              </div>
              <p className="text-3xl font-black text-indigo-900 tracking-tighter">Start: {activeTrip.startOdometerReading} km</p>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Destination</label>
              <input type="text" value={destination} onChange={(e) => setDestination(e.target.value)} placeholder="Where are you going?" className="w-full px-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-2 focus:ring-indigo-500 outline-none font-medium" />
            </div>

            <input type="file" ref={endFileRef} accept="image/*" capture="environment" className="hidden" onChange={onEndPhoto} />
            <button disabled={loading} onClick={handleEndTripStart} className="w-full py-5 bg-slate-900 text-white rounded-2xl font-black text-lg flex items-center justify-center gap-3 hover:bg-slate-800 transition-all shadow-xl disabled:opacity-50">
              {loading ? <Loader2 className="animate-spin" /> : <Camera className="w-6 h-6" />}
              CLOSE TRIP (METER PHOTO)
            </button>
          </div>
        ) : (
          <div className="text-center space-y-8 py-10">
            <div className="w-20 h-20 bg-indigo-100 text-indigo-600 rounded-3xl flex items-center justify-center mx-auto mb-4">
              <Play className="w-10 h-10 fill-indigo-600 translate-x-1" />
            </div>
            <div>
              <p className="text-slate-900 font-black text-xl">Ready to drive?</p>
              <p className="text-slate-400 text-xs font-bold uppercase tracking-widest mt-1">Capture start meter reading</p>
            </div>

            <input type="file" ref={startFileRef} accept="image/*" capture="environment" className="hidden" onChange={onStartPhoto} />
            <button disabled={loading} onClick={handleStartTrip} className="w-full py-5 bg-indigo-600 text-white rounded-2xl font-black text-lg flex items-center justify-center gap-3 hover:bg-indigo-700 transition-all shadow-2xl active:scale-[0.98]">
              {loading ? <Loader2 className="animate-spin" /> : <Camera className="w-6 h-6" />}
              START NEW JOURNEY
            </button>
          </div>
        )}

        {(statusMessage || error) && (
          <div className={`mt-6 p-4 rounded-xl flex items-center gap-3 text-sm font-bold ${error ? 'bg-rose-50 text-rose-600' : 'bg-indigo-50 text-indigo-600 animate-pulse'}`}>
            {error ? <AlertCircle className="w-5 h-5 shrink-0" /> : <Loader2 className="w-5 h-5 animate-spin" />}
            {error || statusMessage}
          </div>
        )}
      </div>

      <div className="space-y-4">
        <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] ml-2">Monthly History</h3>
        <div className="space-y-3">
          {myTrips.filter(t => t.status !== 'IN_PROGRESS').slice(-10).reverse().map(trip => (
            <div key={trip.id} className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${trip.status === 'APPROVED' ? 'bg-emerald-100 text-emerald-600' : trip.status === 'REJECTED' ? 'bg-rose-100 text-rose-600' : 'bg-amber-100 text-amber-600'}`}><MapPin className="w-5 h-5" /></div>
                <div>
                  <p className="font-black text-slate-800 text-sm">{trip.destinationName || 'N/A'}</p>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{new Date(trip.startTime).toLocaleDateString()}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-black text-slate-900">{trip.finalApprovedDistance || trip.distanceKm} km</p>
                <span className={`text-[9px] font-black px-2 py-0.5 rounded-md uppercase tracking-tighter ${trip.status === 'APPROVED' ? 'bg-emerald-50 text-emerald-700' : trip.status === 'REJECTED' ? 'bg-rose-50 text-rose-700' : 'bg-amber-50 text-amber-700'}`}>{trip.status.replace('_', ' ')}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DriverView;
