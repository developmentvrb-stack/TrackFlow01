
import React, { useState } from 'react';
import { User, UserRole } from '../types.ts';
import { Car, Shield, User as UserIcon, ArrowRight, Smartphone, Mail, Lock, Key, ChevronLeft, Download, Info, Monitor, Smartphone as PhoneIcon, Share } from 'lucide-react';

interface LoginProps {
  onLogin: (user: User) => void;
  users: User[];
  setUsers: React.Dispatch<React.SetStateAction<User[]>>;
}

const Login: React.FC<LoginProps> = ({ onLogin, users, setUsers }) => {
  const [roleSelection, setRoleSelection] = useState<UserRole | null>(null);
  const [mode, setMode] = useState<'LOGIN' | 'REGISTER' | 'OTP' | 'HELP'>('LOGIN');
  
  // Form States
  const [email, setEmail] = useState('');
  const [mobile, setMobile] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [empId, setEmpId] = useState('');
  const [managerId, setManagerId] = useState('');
  const [error, setError] = useState('');
  const [otp, setOtp] = useState('');

  const resetForm = () => {
    setEmail('');
    setMobile('');
    setPassword('');
    setName('');
    setEmpId('');
    setError('');
    setOtp('');
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const existingEmail = users.find(u => u.email.toLowerCase() === email.toLowerCase());
    const existingMobile = users.find(u => u.mobile === mobile);

    if (existingEmail) { setError('Email already registered.'); return; }
    if (existingMobile) { setError('Mobile number already registered.'); return; }

    const newUser: User = {
      id: empId || `ID-${Date.now().toString().slice(-4)}`,
      name,
      email,
      mobile,
      password,
      role: roleSelection!,
      assignedManagerId: roleSelection === 'EMPLOYEE' ? (managerId || 'MGR-DEFAULT') : undefined
    };

    setUsers([...users, newUser]);
    alert('Registration Successful!');
    setMode('LOGIN');
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const identifier = email || mobile;
    const user = users.find(u => 
      (u.email.toLowerCase() === identifier.toLowerCase() || u.mobile === identifier) && 
      u.password === password && 
      u.role === roleSelection
    );
    if (user) onLogin(user);
    else setError('Invalid credentials for this role.');
  };

  if (mode === 'HELP') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50 px-4">
        <div className="w-full max-w-md space-y-6 bg-white p-8 sm:p-10 rounded-[2.5rem] shadow-2xl border border-slate-100">
           <button onClick={() => setMode('LOGIN')} className="flex items-center gap-2 text-xs font-black text-slate-400 uppercase tracking-widest hover:text-indigo-600 transition-colors mb-4">
            <ChevronLeft className="w-4 h-4" /> Back to Login
          </button>
          <h2 className="text-2xl font-black text-slate-900 tracking-tight text-center">Install on your Device</h2>
          
          <div className="space-y-6 py-4">
            <div className="flex gap-4">
              <div className="w-10 h-10 rounded-xl bg-indigo-50 flex items-center justify-center shrink-0 text-indigo-600"><PhoneIcon className="w-5 h-5" /></div>
              <div>
                <p className="font-bold text-slate-900 text-sm">Android (Chrome)</p>
                <p className="text-xs text-slate-500 mt-1">Tap the 3 dots (⋮) and select <span className="font-bold text-indigo-600">"Install App"</span> or "Add to Home Screen".</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-10 h-10 rounded-xl bg-rose-50 flex items-center justify-center shrink-0 text-rose-600"><Share className="w-5 h-5" /></div>
              <div>
                <p className="font-bold text-slate-900 text-sm">iPhone (Safari)</p>
                <p className="text-xs text-slate-500 mt-1">Tap the Share button and choose <span className="font-bold text-rose-600">"Add to Home Screen"</span>.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center shrink-0 text-slate-600"><Monitor className="w-5 h-5" /></div>
              <div>
                <p className="font-bold text-slate-900 text-sm">Desktop (PC/Mac)</p>
                <p className="text-xs text-slate-500 mt-1">Click the <Download className="inline w-3 h-3"/> icon in the top-right of your address bar to install.</p>
              </div>
            </div>
          </div>
          <div className="p-4 bg-amber-50 rounded-2xl border border-amber-100 text-[10px] text-amber-700 font-bold uppercase tracking-widest text-center">
            No Play Store or App Store required
          </div>
        </div>
      </div>
    );
  }

  if (!roleSelection) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950 px-4">
        <div className="w-full max-w-md space-y-8">
          <div className="text-center">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-indigo-600 text-white mb-6 shadow-2xl">
              <Car className="w-10 h-10" />
            </div>
            <h1 className="text-4xl font-black text-white tracking-tight">TrackFlow</h1>
            <p className="mt-2 text-slate-400 font-medium">Enterprise Management System</p>
          </div>

          <div className="grid grid-cols-1 gap-4">
            <button onClick={() => setRoleSelection('EMPLOYEE')} className="group relative p-8 bg-slate-900 border border-slate-800 rounded-[2rem] text-left hover:border-indigo-500 transition-all">
              <div className="flex items-center gap-4 mb-2">
                <div className="p-3 bg-indigo-500/10 rounded-xl text-indigo-500"><UserIcon className="w-6 h-6" /></div>
                <h3 className="text-xl font-bold text-white">Staff Portal</h3>
              </div>
              <p className="text-slate-500 text-sm">Submit trips and view payments.</p>
            </button>
            <button onClick={() => setRoleSelection('MANAGER')} className="group relative p-8 bg-slate-900 border border-slate-800 rounded-[2rem] text-left hover:border-amber-500 transition-all">
              <div className="flex items-center gap-4 mb-2">
                <div className="p-3 bg-amber-500/10 rounded-xl text-amber-500"><Shield className="w-6 h-6" /></div>
                <h3 className="text-xl font-bold text-white">Admin Portal</h3>
              </div>
              <p className="text-slate-500 text-sm">Audit locations and approvals.</p>
            </button>
          </div>
          
          <button onClick={() => setMode('HELP')} className="w-full flex items-center justify-center gap-2 text-slate-500 text-xs font-bold uppercase tracking-widest hover:text-white transition-colors">
            <Info className="w-4 h-4" /> Installation Guide for Mobile/PC
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 px-4">
      <div className="w-full max-w-md space-y-6 bg-white p-8 sm:p-10 rounded-[2.5rem] shadow-2xl border border-slate-100">
        <div className="flex justify-between items-center mb-4">
          <button onClick={() => { setRoleSelection(null); resetForm(); setMode('LOGIN'); }} className="flex items-center gap-2 text-xs font-black text-slate-400 uppercase tracking-widest hover:text-indigo-600 transition-colors">
            <ChevronLeft className="w-4 h-4" /> Back
          </button>
          <button onClick={() => setMode('HELP')} className="p-2 text-slate-300 hover:text-indigo-600 transition-colors"><Info className="w-5 h-5" /></button>
        </div>

        <div className="text-center">
          <span className={`inline-block px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest mb-2 ${roleSelection === 'MANAGER' ? 'bg-amber-100 text-amber-700' : 'bg-indigo-100 text-indigo-700'}`}>
            {roleSelection} ACCESS
          </span>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">
            {mode === 'LOGIN' ? 'Sign In' : mode === 'REGISTER' ? 'Register' : 'Verification'}
          </h2>
        </div>

        {error && <div className="p-4 bg-rose-50 border border-rose-100 rounded-2xl text-rose-600 text-xs font-bold text-center">{error}</div>}

        {mode === 'REGISTER' ? (
          <form className="space-y-4" onSubmit={handleRegister}>
            <InputField icon={<UserIcon className="w-4 h-4"/>} label="Full Name" value={name} onChange={setName} required />
            <InputField icon={<Mail className="w-4 h-4"/>} label="Email/Gmail" type="email" value={email} onChange={setEmail} required />
            <InputField icon={<Smartphone className="w-4 h-4"/>} label="Mobile" type="tel" value={mobile} onChange={setMobile} required />
            <InputField icon={<Lock className="w-4 h-4"/>} label="Password" type="password" value={password} onChange={setPassword} required />
            <InputField icon={<Key className="w-4 h-4"/>} label="Employee Code" value={empId} onChange={setEmpId} required />
            <button type="submit" className="w-full py-4 bg-slate-900 text-white rounded-2xl font-black hover:bg-slate-800 shadow-xl transition-all">CREATE ACCOUNT</button>
            <p className="text-center text-xs font-bold text-slate-400">Already have an account? <button type="button" onClick={() => setMode('LOGIN')} className="text-indigo-600 underline">Login</button></p>
          </form>
        ) : mode === 'OTP' ? (
          <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); if(otp === '1234') { const user = users.find(u => u.email === email || u.mobile === mobile); if(user) onLogin(user); } else setError('Wrong OTP'); }}>
            <div className="bg-slate-50 p-8 rounded-3xl text-center">
              <p className="text-xs text-slate-400 font-bold uppercase mb-4 tracking-widest">Enter Code: 1234</p>
              <input required type="text" maxLength={4} value={otp} onChange={(e) => setOtp(e.target.value)} className="w-full bg-transparent text-center text-5xl font-black tracking-[0.2em] focus:outline-none" placeholder="0000" />
            </div>
            <button type="submit" className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-black hover:bg-indigo-700 shadow-lg">CONTINUE</button>
            <button type="button" onClick={() => setMode('LOGIN')} className="w-full text-xs font-bold text-slate-400 uppercase tracking-widest">Back</button>
          </form>
        ) : (
          <form className="space-y-5" onSubmit={handleLogin}>
            <InputField icon={<Mail className="w-4 h-4"/>} label="Email or Mobile" value={email || mobile} onChange={(v) => {setEmail(v); setMobile(v);}} required />
            <InputField icon={<Lock className="w-4 h-4"/>} label="Password" type="password" value={password} onChange={setPassword} required />
            <button type="submit" className="w-full py-4 bg-slate-900 text-white rounded-2xl font-black hover:bg-slate-800 shadow-xl transition-all">SIGN IN</button>
            <div className="flex flex-col gap-4 text-center">
              <button type="button" onClick={() => { 
                const u = users.find(u => (u.email === email || u.mobile === mobile) && u.role === roleSelection);
                if(u) { alert('OTP: 1234 sent!'); setMode('OTP'); } else setError('Account not found.');
              }} className="text-xs font-bold text-indigo-600">Forgot Password? Sign in with OTP</button>
              <div className="h-px bg-slate-100"></div>
              <p className="text-xs font-bold text-slate-400">New? <button type="button" onClick={() => setMode('REGISTER')} className="text-indigo-600 underline">Register Now</button></p>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};

const InputField = ({ icon, label, type = "text", value, onChange, required = false }: any) => (
  <div className="space-y-1">
    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">{label}</label>
    <div className="relative group">
      <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors">{icon}</div>
      <input required={required} type={type} value={value} onChange={(e) => onChange(e.target.value)} className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-100 rounded-2xl focus:bg-white focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none font-medium text-sm transition-all shadow-sm" />
    </div>
  </div>
);

export default Login;
