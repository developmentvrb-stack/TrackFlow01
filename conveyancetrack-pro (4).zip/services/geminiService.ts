
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const extractOdometerReading = async (base64Image: string): Promise<number | null> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: 'image/jpeg',
              data: base64Image.split(',')[1] || base64Image,
            },
          },
          {
            text: "Extract the current numeric odometer reading from this image. Only return the number, no decimals if they are not clear. If there are multiple numbers, choose the one that represents the total mileage/kilometers. Return exactly one number or 'null' if not found."
          }
        ]
      },
      config: {
        temperature: 0.1,
      }
    });

    const result = response.text?.trim();
    if (!result || result.toLowerCase() === 'null') return null;
    
    const numericValue = parseFloat(result.replace(/[^0-9.]/g, ''));
    return isNaN(numericValue) ? null : numericValue;
  } catch (error) {
    console.error("Gemini OCR Error:", error);
    return null;
  }
};
